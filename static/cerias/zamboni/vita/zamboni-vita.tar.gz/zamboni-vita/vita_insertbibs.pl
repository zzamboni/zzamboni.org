eval 'exec perl -x $0 ${1+"$@"}' # -*-perl-*-
  if 0;
#!perl -w
#
# Scan an html file and replace any text of the form:
#   latex2html_insert_bib(key1,key2,...)
# with the html text corresponding to that entry in the
# $HTMLBIB file.

use strict;
use vars qw(
	    $HTMLBIB
	    %entries
	    $debug
	   );

$HTMLBIB="vitabib/vitabib.html";

$debug=0;

# First read the HTMLBIB file and store the entries in a hash
# by key.
{
  my $cur_key;
  my $cur_entry;
  my $in_entry=0;
  local @ARGV=($HTMLBIB);
  %entries=();
  while (<>) {
    if (/^<DT><A NAME="(.*)".*$/) {
      $cur_key=$1;
      $in_entry=1;
      $cur_entry="";
      next;
    }
    # Capture text within each entry, except for the <DD> and the standalone <BR> and <P>
    if ($in_entry) {
      unless (/^<(DD|BR|P)>$/) {
	$cur_entry .= $_;
      }
    }
    if ($in_entry && /^<P>$/) {
      # Each entry is terminated by a lone <p>

      # Store the entry and reset things
      $entries{$cur_key}=$cur_entry;
      # Make links for URLs. In this particular case, a < immediately follows
      # each URL. We also add links to PDF versions of the papers, by simply
      # replacing the .ps with .pdf.
      if ($entries{$cur_key} =~ /(http[^<]+)/) {
	my $url=$1;
	my $urlpdf=$url;
	$urlpdf=~s/\.ps$/.pdf/;
	# No pdf url if the substitution was unsuccessful
	if ($url ne $urlpdf) {
	  $urlpdf=qq[<A HREF="$urlpdf">PDF</A>];
	}
	else {
	  $urlpdf="";
	}
	# See if we can remove the whole URL ... thing and instead link from the
	# title of the paper.
	if ($urlpdf &&
	    $entries{$cur_key} =~ s!<BR>\s*URL\s*<TT>\s*$url\s*</TT>\.\s*!!s) {
	  $urlpdf=", $urlpdf";
	  # In this case, add the links after the title. The title is everything between
	  # the first and second <BR>
	  $entries{$cur_key} =~ s!<BR>(.*?)\.(\s*)<BR>!<BR>$1 (<A HREF="$url">Postscript</A>$urlpdf).$2<BR>!s;
	}
	elsif ($url =~ /\.pdf$/ &&
	       $entries{$cur_key}=~
	         s!<BR>\s*URL\s*<TT>\s*$url\s*</TT>\.\s*!!s) {
	  $entries{$cur_key} =~ s!<BR>(.*?)\.(\s*)<BR>!<BR>$1 (<A HREF="$url">PDF</A>).$2<BR>!s;
	}
	else {
	  # If not, simply convert the url to a link, adding the pdf link if possible.
	  $urlpdf=" ($urlpdf)" if $urlpdf;
	  $entries{$cur_key} =~ s!$url!<A HREF="$url">$url</A>$urlpdf!;
	}
      }

      # Fix years followed by a letter that are inserted by latex2html
      $entries{$cur_key} =~ s/(19\d\d|200\d)[\w]/$1/;

      warn "Got entry $cur_key:\n$cur_entry\n" if $debug;
      $in_entry=0;
    }
  }
}

# Now the entries are stored in %entries, we scan the input file.
while (<>) {
  if (s/latex2html_insert_bib\(([^\)]+)\)//) {
    print;
    my @keys=split(/,/,$1);
    print "<UL>\n";
    foreach (@keys) {
      if (exists($entries{$_})) {
	print "<LI>".$entries{$_}."<P></LI>";
	warn "Inserting entry for key $_\n" if $debug;
      }
      else {
	warn "I don't have an entry for key $_\n";
      }
    }
    print "</UL>"
  }
  else {
    print;
  }
}
