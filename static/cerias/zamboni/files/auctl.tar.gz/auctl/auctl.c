#include <stdio.h>
#include <sys/audioio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

extern int optind;

main(int argc, char *argv[]) {
    audio_info_t auinfo;
    int aufd;
    int err;
    int verb=0;
    int c;

    while ((c = getopt(argc, argv, "vh")) != EOF) {
	switch (c) {
	    case 'v':
		    verb=1;
		    break;
	    case 'h':
	    case '?':
		    fprintf(stderr, "usage: auctl [-v] vol [+-=]n | mute | ( port spkr|hdphone|line )\n");
		    exit(1);
	}
    }

    if (verb > 1) {
	    int i;
	    fprintf(stderr, "My arguments: ");
	    for (i=0; i<argc; i++)
		    fprintf(stderr,"%s ", argv[i]);
	    fprintf(stderr, "\n");
    }

    AUDIO_INITINFO(&auinfo);
    aufd=open("/dev/audioctl", O_RDWR | O_NDELAY);
    if(aufd==-1) {
	fprintf(stderr, "auctl: Error opening /dev/audioctl\n");
	exit(1);
    }
    err=ioctl(aufd, AUDIO_GETINFO, &auinfo);
    if(err!=0) {
	fprintf(stderr, "ioctl error on read: %d\n", err);
    }


    if(strcmp(argv[optind], "vol")==0) {
	int gain;
	char *msg;
	if(argv[optind+1][0]=='=') {
	    gain=atoi(&argv[optind+1][1]);
	    msg="Setting";
	}
	else {
	    int volinc=atoi(argv[optind+1]);
	    gain=auinfo.play.gain+volinc;
	    if (volinc>0)
		    msg="Increasing";
	    else
		    msg="Decreasing";
	}

	AUDIO_INITINFO(&auinfo);
	
	if(gain>255) gain=255;
	if(gain<0) gain=0;

	if (verb) {
		int pct = (gain*100)/255;
		fprintf(stderr,"%s volume to %d (%d%%)\n", msg, gain, pct);
	}

	auinfo.play.gain=gain;

	err=ioctl(aufd, AUDIO_SETINFO, &auinfo);
	if(err!=0) {
	    fprintf(stderr, "ioctl error on write: %d\n", err);
	}
    }

    if(strcmp(argv[optind], "mute")==0) {
	int muted=auinfo.output_muted;

	AUDIO_INITINFO(&auinfo);
	
	auinfo.output_muted=(muted==0);

	if (verb) {
		if (auinfo.output_muted)
			fprintf(stderr,"Muting.\n");
		else
			fprintf(stderr,"Disabling muting.\n");
	}

	err=ioctl(aufd, AUDIO_SETINFO, &auinfo);
	if(err!=0) {
	    fprintf(stderr, "ioctl error on write: %d\n", err);
	}
	
    }

    if(strcmp(argv[optind], "port")==0) {
	int port=auinfo.play.port;
	
	if(strcmp(argv[optind+1], "spkr")==0)
	    port^=AUDIO_SPEAKER;
	else if(strcmp(argv[optind+1], "hdphone")==0)
	    port^=AUDIO_HEADPHONE;
	else if(strcmp(argv[optind+1], "line")==0)
	    port^=AUDIO_LINE_OUT;
	else {
	    fprintf(stderr, "Unknown port. Valid choices: spkr hdphone line\n");
	    exit(1);
	}

	if (verb)
		fprintf(stderr,"Toggling output on %s\n", argv[optind+1]);

	AUDIO_INITINFO(&auinfo);
	
	auinfo.play.port=port;

	err=ioctl(aufd, AUDIO_SETINFO, &auinfo);
	if(err!=0) {
	    fprintf(stderr, "ioctl error on write: %d\n", err);
	}
	
    }

    close(aufd);
    exit(0);
}
